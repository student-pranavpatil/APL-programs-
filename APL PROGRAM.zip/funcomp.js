import React from 'react';
function Hello()
{
    return(
        <div>
            <h1>Hello</h1>
        </div>
    );

}
export default Hello;