import React from 'react';
class Welcome1 extends React.Component
{
    render(){
        return(
            <div style={{color:'blue',fontSize:'20px'}}>
                <h1>Hello World</h1>
            </div>
        );
    }
}
export default Welcome1;