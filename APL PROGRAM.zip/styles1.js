import React from 'react';
import Styles from './styles1.css'
class Welcome extends React.Component
{
    render(){
        return(
            <div>
                <h1>Hello World</h1>
            </div>
        );
    }
}
export default Welcome;