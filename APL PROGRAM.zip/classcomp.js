import React from 'react';
class Helloworld extends React.Component
{
    render(){
        return(
            <div>
                <h1>Hello World</h1>
            </div>
        );
    }
}
export default Helloworld;