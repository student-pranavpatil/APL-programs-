import React from 'react';
import Styles from './styles3.module.css';

class Welcome2 extends React.Component
{
    render(){
        return(
            <div className='Styles'>
                <h1>Hello World</h1>
            </div>
        );
    }
}
export default Welcome2;