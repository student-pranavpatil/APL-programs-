import React from "react";

function SelectQuiz() {
  return (
    <div style={{ padding: "20px" }}>
      <h2>Select a Quiz</h2>
      <p>Here you will see available quizzes after choosing standard/subject.</p>
    </div>
  );
}

export default SelectQuiz;
